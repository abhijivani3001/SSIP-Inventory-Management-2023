import React from 'react';

const CartContext = React.createContext();

export default CartContext;
