import { createContext } from 'react';

const MergeContext = createContext();

export default MergeContext;
