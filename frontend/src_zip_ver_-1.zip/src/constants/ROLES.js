const ROLES = {
  ADMIN: 'admin',
  EMPLOYEE: 'employee',
  SUB_BRANCH_STORE_MANAGER: 'sub-branch-store-manager',
  SUB_BRANCH_HEAD: 'sub-branch-head',
  BRANCH_STORE_MANAGER: 'branch-store-manager',
  BRANCH_HEAD: 'branch-head',
  DEPARTMENT_STORE_MANAGER: 'department-store-manager',
  DEPARTMENT_HEAD: 'department-head',
};

export default ROLES;
